from lstore.config import *

class Page:

    def __init__(self):
        self.num_records = 0
        self.data = bytearray(PAGESIZE)

    """
    Checks if there is space left in page
    """
    def has_capacity(self):
        return self.num_records < PAGESIZE/DATASIZE

    """
    Converts a value that may be string, int, etc. to bytes
    """
    def convert_to_bytes(self, value):
        if (isinstance(value, str)):
            insert = bytes(value, 'utf-8')
        elif (isinstance(value, int)):
            insert = value.to_bytes(8,byteorder = "big")
        elif (value == None):
            insert = bytearray(8)
        else:
            insert = bytes(value)
        return insert

    """
    Appends a new value at the first empty entry in page
    """
    def write(self, value):
        if (self.has_capacity()):
            insert = self.convert_to_bytes(value)
            # Find position of empty space and insert data at that index
            pos = self.num_records * DATASIZE
            self.data[pos:pos+len(insert)] = insert
            self.num_records += 1
            return True
        return False

    """
    Replaces current value at record_index with new value given
    """
    def overwrite_record(self, record_index, value):
        if (record_index < PAGESIZE/DATASIZE):
            insert = self.convert_to_bytes(value)
            # Find byte position corresponding to record and overwrite the data
            pos = record_index * DATASIZE
            self.data[pos:pos+(DATASIZE)] = insert
            return True
        return False

    """
    Reads the value at the given index
    :return: bytearray of 8 bytes
    """
    def read(self, index):
        if (index < PAGESIZE/DATASIZE):
            # Find byte position corresponding to record and read the data
            pos = index * DATASIZE
            value = self.data[pos:pos+(DATASIZE)]
            return value
            #print("".join("\\x%02x" % i for i in value))
