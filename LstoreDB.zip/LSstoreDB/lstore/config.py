# Global Setting for the Database
# PageSize, StartRID, etc..
PAGESIZE=4096
DATASIZE=8

def init():
    pass
